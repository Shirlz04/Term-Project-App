package com.example.project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Game#newInstance} factory method to
 * create an instance of this fragment.
 */
public  class Game extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Callbacks mcallbacks;
    private ImageButton[][] buttons;
    private String[][] board;
    private Bundle bund;
    private int count, holder, buttonIDs[][];
    private ImageView imageView;
    private Thread thread;
    private ImageButton imageButton;
    private Map<Integer,Integer> rowMap;
    private Map<Integer,Integer> columnMap;
    private int row,column,lastRow, lastColumn, redPlayerCount, blackPlayerCount;
    private boolean blackButtonTouched, redButtonTouched, takeable, multiple, directionLR, firstSearch;
    private int blackIdMove,redIdMove;
    private boolean player, taken, crownTakeable, cpu;
    private boolean[][] takeableMoves;
    private LinkedList<Integer> blackIds;

    public Game() {
        // Required empty public constructor
        buttons = new ImageButton[8][8];
        blackIds = new LinkedList<Integer>();
         count = 1;
         row = 0;
         redPlayerCount = 12;
         blackPlayerCount = 12;

         column = 0;
         crownTakeable = false;
         lastColumn = 0;
         lastRow = 0;
         blackButtonTouched = false;
         directionLR = false;  //false = left & true = right
         redButtonTouched = false;
         buttonIDs = new  int[8][8];
         takeable = false;
         multiple = false;
         taken = false;
         firstSearch = true;
         holder = 0;
         redIdMove = 0;
         blackIdMove = 0;
         board = new String[8][8];
         for (int i = 0; i < 8; i++){
             for (int j = 0; j < 8; j++){
                 board[i][j] = " ";
             }
         }
         rowMap = new HashMap<Integer, Integer>();
         columnMap = new HashMap<Integer, Integer>();
         player = false;

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Game.
     */
    // TODO: Rename and change types and number of parameters
    public static Game newInstance(String param1, String param2) {
        Game fragment = new Game();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        mcallbacks = (Callbacks) activity;
    }

    public interface Callbacks {
        void playerTurn(boolean player);
        void penaltyCheck();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_game, container, false);
        //imageButton = view.findViewById(R.id.tester);
        mcallbacks.playerTurn(player);
        cpu = false;
        bund = this.getArguments();
        cpu = bund.getBoolean("cpuGame");
        boolean switcher = true;
        for (int i = 0; i < 8; i++) {
            if (switcher){ switcher = false; }
            else { switcher = true; }
            for (int j = 0; j < 8; j++) {
                String newID = "button" + Integer.toString(count);
                int id = getResources().getIdentifier(newID, "id", "com.example.project");

                buttons[i][j] = (ImageButton) view.findViewById(id);
                buttonIDs[i][j] = id;
                rowMap.put(id,i);
                columnMap.put(id,j);
                if(!switcher){
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                    switcher = true;
                    if (count < 24){
                        buttons[i][j].setImageResource(R.drawable.black);
                        board[i][j] = "B";
                        //System.out.println(id);
                        blackIds.add(id);
                    }
                    if  (count > 41 ){
                        buttons[i][j].setImageResource(R.drawable.red);
                        board[i][j] = "R";
                    }
                }
                else{
                    buttons[i][j].setBackgroundColor(Color.RED);
                    switcher = false;
                    board[i][j] = "-";
                }
                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ImageButton temp = view.findViewById(id);
                        holder = id;
                        if(!player) {
                            Toast.makeText(getContext(),"Red's Turn",Toast.LENGTH_SHORT).show();
                            if (redButtonTouched) {
                                //System.out.println("red" + redIdMove);

                                thread = new Thread(runnable);
                                thread.start();
                            } else {
                                setNewLocation(id);
                            }
                        }
                        else{
                            /*if (cpu){
                                cpuMove();
                            }
                            else */if (blackButtonTouched) {
                                Toast.makeText(getContext(),"Black's Turn",Toast.LENGTH_SHORT).show();
                                //System.out.println("black" + blackIdMove);
                                thread = new Thread(runnable);
                                thread.start();
                            } else {
                                 setNewLocationBlack(id);
                            }
                        }
                    }
                });
                count++;
            }
        }
        return view;
    }

    public void setNewLocation(int id) throws ArrayIndexOutOfBoundsException{
        //System.out.println(taken);
        row = Integer.parseInt(rowMap.get(id).toString());
        column = Integer.parseInt(columnMap.get(id).toString());
        if (board[row][column].equals("B") || board[row][column].equals("BC")){
            return;
        }
        if (board[row][column].equals("RC")){ crownMover(row,column); }
        else if((row - 1) >= 0){
            if ((column - 1) >= 0){// check if the left move is available
                if ((board[row -1][column - 1].equals(" "))){
                    buttons[row -1][column -1].setBackgroundColor(Color.GREEN);
                    buttons[row -1][column -1].setImageResource(R.color.green);
                    board[row - 1][column - 1] = "G";
                }
                if (row - 2 >= 0 && column - 2 >= 0 && (board[row -1][column - 1].equals("B") ||
                        board[row -1][column - 1].equals("BC") ) && board[row -2][column - 2].equals(" ") ){
                    buttons[row -2][column -2].setBackgroundColor(Color.GREEN);
                    buttons[row -2][column -2].setImageResource(R.color.green);
                    board[row - 2][column - 2] = "G";
                    takeable = true;
                    //System.out.println("6655454545");
                    System.out.println("ERROR");
                }
                if (row + 2 <= 7 && column - 2 >= 0 && (board[row +1][column - 1].equals("B") ||
                        board[row +1][column - 1].equals("BC")) && board[row +2][column - 2].equals(" ")){
                    buttons[row +2][column -2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column -2].setImageResource(R.color.green);
                    board[row + 2][column - 2] = "G";
                    System.out.println("464854548");
                    takeable = true;
                    System.out.println("ERROR");
                }

            }
            if ((column + 1) <= 7) {
                if (board[row - 1][column + 1].equals(" ")) {//check if the right move is available
                    buttons[row - 1][column + 1].setBackgroundColor(Color.GREEN);
                    buttons[row - 1][column + 1].setImageResource(R.color.green);
                    board[row - 1][column + 1] = "G";
                }
                if (row - 2 >= 0 && column + 2 <= 7 && (board[row -1][column + 1].equals("B") ||
                        board[row -1][column + 1].equals("BC"))  && board[row -2][column +2].equals(" ")){
                    buttons[row -2][column +2].setBackgroundColor(Color.GREEN);
                    buttons[row -2][column +2].setImageResource(R.color.green);
                    board[row -2][column + 2] = "G";
                    System.out.println("79798978");
                    takeable = true;
                }
                if (row + 2 <= 7 && column + 2 <= 7 && (board[row +1][column + 1].equals("B") ||
                        board[row +1][column + 1].equals("BC")) && board[row +2][column + 2].equals(" ") ){
                    buttons[row +2][column +2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column +2].setImageResource(R.color.green);
                    board[row + 2][column +2] = "G";
                    takeable = true;
                    System.out.println("BACKWARD TO RIGHT");
                }
            }

        }
        //multipleTakeSearch(id);
        if (!redButtonTouched){
            redButtonTouched = true;
            redIdMove = id;
        }
        if (board[row][column].equals("RC")) { crownMover(row, column); }
    }

    public void setNewLocationBlack(int id) throws  ArrayIndexOutOfBoundsException{
       // System.out.println(taken);
        row = Integer.parseInt(rowMap.get(id).toString());
        column = Integer.parseInt(columnMap.get(id).toString());
        if (board[row][column].equals("R") || board[row][column].equals("RC")){
            return;
        }
        //if (multipleTakeSearch(id)){ return; }
        if (board[row][column].equals("BC")){ crownMover(row,column); }
        else if((row + 1) <= 7) {
            if ((column - 1) >= 0) {
                if (board[row + 1][column - 1].equals(" ")) {
                    buttons[row + 1][column - 1].setBackgroundColor(Color.GREEN);
                    buttons[row + 1][column - 1].setImageResource(R.color.green);
                    board[row + 1][column - 1] = "G";

                }
                if (row + 2 <= 7 && column - 2 >= 0 && !board[row +1][column - 1].equals(" ")
                        && board[row +2][column - 2].equals(" ") &&
                        (board[row +1][column - 1].equals("R") || board[row +1][column - 1].equals("RC"))){
                    buttons[row +2][column -2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column -2].setImageResource(R.color.green);
                    board[row + 2][column - 2] = "G";
                    takeable = true;
                    System.out.println("Black takable left");
                }
                if (row - 2 >= 0 && column - 2 >= 0 && (board[row -1][column - 1].equals("R") ||
                        board[row -1][column - 1].equals("RC")) && board[row -2][column - 2].equals(" ")){
                    buttons[row -2][column -2].setBackgroundColor(Color.GREEN);
                    buttons[row -2][column -2].setImageResource(R.color.green);
                    board[row - 2][column - 2] = "G";
                    System.out.println("58797477");
                    takeable = true;
                    System.out.println("ERROR");
                }

            }
            if ((column + 1) <= 7) {
                if (board[row + 1][column + 1].equals(" ")) {
                    buttons[row + 1][column + 1].setBackgroundColor(Color.GREEN);
                    buttons[row + 1][column + 1].setImageResource(R.color.green);
                    board[row + 1][column + 1] = "G";
                }
                if (row + 2 <= 7 && column + 2 <= 7 && column - 1 >= 0 && column +1 <= 7
                        && board[row +2][column + 2].equals(" ")
                        && (board[row +1][column + 1].equals("RC") || board[row +1][column + 1].equals("R"))){
                    buttons[row +2][column +2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column +2].setImageResource(R.color.green);
                    board[row + 2][column +2] = "G";
                    takeable = true;
                    System.out.println("Black takable right");
                }
                if (row - 2 >= 0 && column + 2 <= 7 && (board[row -1][column + 1].equals("R")
                        || board[row -1][column + 1].equals("RC")) && board[row -2][column + 2].equals(" ")){
                    buttons[row -2][column +2].setBackgroundColor(Color.GREEN);
                    buttons[row -2][column +2].setImageResource(R.color.green);
                    board[row -2][column +2] = "G";
                    takeable = true;
                    System.out.println("2225252");
                    System.out.println("ERROR");
                }

            }
        }
        //multipleTakeSearch(id);

         if (!blackButtonTouched) {
            blackButtonTouched = true;
            blackIdMove = id;
        }
        if (board[row][column].equals("BC")) { crownMover(row, column); }
    }

    public boolean setNewCPUMove(int id) throws  ArrayIndexOutOfBoundsException{
        boolean hasMove = false;
        // System.out.println(taken);
        row = Integer.parseInt(rowMap.get(id).toString());
        column = Integer.parseInt(columnMap.get(id).toString());
        //if (multipleTakeSearch(id)){ return; }
        if (board[row][column].equals("BC")){ crownMover(row,column); }
        else if((row + 1) <= 7) {
            if ((column - 1) >= 0) {
                if (board[row + 1][column - 1].equals(" ")) {
                    buttons[row + 1][column - 1].setBackgroundColor(Color.GREEN);
                    board[row + 1][column - 1] = "G";
                    hasMove = true;

                }
                if (row + 2 <= 7 && column - 2 >= 0 && !board[row +1][column - 1].equals(" ")
                        && board[row +2][column - 2].equals(" ") &&
                        (board[row +1][column - 1].equals("R") || board[row +1][column - 1].equals("RC"))){
                    buttons[row +2][column -2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column -2].setImageResource(R.color.green);
                    board[row + 2][column - 2] = "G";
                    takeable = true;
                    hasMove = true;
                    System.out.println("Black takable left");
                }
                if (row - 2 >= 0 && column - 2 >= 0 && (board[row -1][column - 1].equals("R") ||
                        board[row -1][column - 1].equals("RC")) && board[row -2][column - 2].equals(" ")){
                    buttons[row -2][column -2].setBackgroundColor(Color.GREEN);
                    board[row - 2][column - 2] = "G";
                    System.out.println("58797477");
                    takeable = true;
                    hasMove = true;
                    System.out.println("ERROR");
                }

            }
            if ((column + 1) <= 7) {
                if (board[row + 1][column + 1].equals(" ")) {
                    buttons[row + 1][column + 1].setBackgroundColor(Color.GREEN);
                    board[row + 1][column + 1] = "G";
                    hasMove = true;
                }
                if (row + 2 <= 7 && column + 2 <= 7 && column - 1 >= 0 && column +1 <= 7
                        && board[row +2][column + 2].equals(" ")
                        && (board[row +1][column + 1].equals("RC") || board[row +1][column + 1].equals("R"))){
                    buttons[row +2][column +2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column +2].setImageResource(R.color.green);
                    board[row + 2][column +2] = "G";
                    takeable = true;
                    hasMove = true;
                    System.out.println("Black takable right");
                }
                if (row - 2 >= 0 && column + 2 <= 7 && (board[row -1][column + 1].equals("R")
                        || board[row -1][column + 1].equals("RC")) && board[row -2][column + 2].equals(" ")){
                    buttons[row -2][column +2].setBackgroundColor(Color.GREEN);
                    board[row -2][column +2] = "G";
                    takeable = true;
                    hasMove = true;
                    System.out.println("2225252");
                    System.out.println("ERROR");
                }

            }
        }
        //multipleTakeSearch(id);

        if (!blackButtonTouched) {
            blackButtonTouched = true;
            blackIdMove = id;
        }
        if (board[row][column].equals("BC")) { crownMover(row, column); }
        return hasMove;
    }

    public void cpuMove(){
        boolean moveable;
        for (int i : blackIds){
            moveable = setNewCPUMove(i);
            if(moveable){
                for (int a = 0; a < 8; a++){
                    for (int b = 0; b < 8; b++){
                        if (board[a][b].equals("G")){
                            System.out.println(i);
                            makeMove(i,buttonIDs[a][b]);
                        }
                    }
                }
                break;
            }
            System.out.println(i);
        }

    }



    public void makeMove(int id, int newIdMove) throws ArrayIndexOutOfBoundsException{
        System.out.println("1. takeable: "+takeable+" taken: "+taken);
        if (!allowedMove(id,newIdMove)){
            clearHelp();
            redButtonTouched = false;
            redIdMove = 0;
            blackIdMove = 0;
            blackButtonTouched = false;
            return;
        }
        takeCheck();
        System.out.println("2. takeable: "+takeable+" taken: "+taken);
        //multipleTakeSearch(id);
        buttons[row][column].setImageResource(R.color.black);
        buttons[row][column].setBackgroundColor(Color.BLACK);
        int rowTemp = Integer.parseInt(rowMap.get(newIdMove).toString());
        int columnTemp = Integer.parseInt(columnMap.get(newIdMove).toString());
        buttons[rowTemp][columnTemp].setBackgroundColor(Color.BLACK);

        if (!player) {
            if(takeable){
                if(rowTemp < row) {
                    if (columnTemp > column && row - 1 >= 0 && column + 1 <= 7 && (board[row - 1][column + 1].equals("B")
                            || board[row - 1][column + 1].equals("BC"))) {
                        buttons[row - 1][column + 1].setImageResource(R.color.black);
                        buttons[row - 1][column + 1].setBackgroundColor(Color.BLACK);
                        board[row - 1][column + 1] = " ";
                        takeable = false;
                    } else if (columnTemp < column && row - 1 >= 0 && column - 1 >= 0 && (board[row - 1][column - 1].equals("B")
                            || board[row - 1][column - 1].equals("BC"))) {
                        buttons[row - 1][column - 1].setImageResource(R.color.black);
                        buttons[row - 1][column - 1].setBackgroundColor(Color.BLACK);
                        board[row - 1][column - 1] = " ";
                        takeable = false;
                    }
                    taken = true;
                }
                else if(rowTemp > row){
                    if (columnTemp > column && row + 1 <= 7 && column + 1 <= 7 && (board[row + 1][column + 1].equals("B")
                            || board[row + 1][column + 1].equals("BC"))) {
                        buttons[row + 1][column + 1].setImageResource(R.color.black);
                        buttons[row + 1][column + 1].setBackgroundColor(Color.BLACK);
                        board[row + 1][column + 1] = " ";
                        takeable = false;
                    } else if (columnTemp < column && row + 1 <= 7  && column - 1 >= 0 && (board[row + 1][column - 1].equals("B")
                            || board[row + 1][column - 1].equals("BC"))) {
                        buttons[row + 1][column - 1].setImageResource(R.color.black);
                        buttons[row + 1][column - 1].setBackgroundColor(Color.BLACK);
                        board[row + 1][column - 1] = " ";
                        takeable = false;
                    }
                    taken = true;
                }
            }
            else if (crownTakeable){ crownTaker(row,column,rowTemp,columnTemp);}
            if (rowTemp == 0 || board[row][column].equals("RC")){
                buttons[rowTemp][columnTemp].setImageResource(R.drawable.red_crown);
                board[rowTemp][columnTemp] = "RC";
                player = true;
            }
            else {
                buttons[rowTemp][columnTemp].setImageResource(R.drawable.red);
                board[rowTemp][columnTemp] = "R";
                player = true;
            }
        }
        else{
            if(takeable){
                if(rowTemp > row) {
                    if (columnTemp > column && column + 1 <= 7 &&
                            (board[row + 1][column + 1].equals("R") || board[row + 1][column + 1].equals("RC") )) {
                        buttons[row + 1][column + 1].setImageResource(R.color.black);
                        buttons[row + 1][column + 1].setBackgroundColor(Color.BLACK);
                        board[row + 1][column + 1] = " ";
                        takeable = false;
                    } else if (columnTemp < column && column - 1 >= 0 &&
                            (board[row + 1][column - 1].equals("R") || board[row + 1][column - 1].equals("RC"))){
                        buttons[row + 1][column - 1].setImageResource(R.color.black);
                        buttons[row + 1][column - 1].setBackgroundColor(Color.BLACK);
                        board[row + 1][column - 1] = " ";
                        takeable = false;
                    }
                    taken = true;
                }
                else if (rowTemp < row){
                    if (columnTemp > column && column + 1 <= 7 &&
                            (board[row - 1][column + 1].equals("R") || board[row - 1][column + 1].equals("RC"))) {
                        buttons[row - 1][column + 1].setImageResource(R.color.black);
                        buttons[row - 1][column + 1].setBackgroundColor(Color.BLACK);
                        board[row - 1][column + 1] = " ";
                        takeable = false;
                    } else if (columnTemp < column && column - 1 >= 0 &&
                            (board[row - 1][column - 1].equals("R") || board[row - 1][column - 1].equals("RC"))){
                        buttons[row - 1][column - 1].setImageResource(R.color.black);
                        buttons[row - 1][column - 1].setBackgroundColor(Color.BLACK);
                        board[row - 1][column - 1] = " ";
                        takeable = false;
                    }
                    taken = true;
                }
            }
            if (rowTemp == 7 || board[row][column].equals("BC")){
                buttons[rowTemp][columnTemp].setImageResource(R.drawable.black_crown);
                board[rowTemp][columnTemp] = "BC";
                player = false;
            }
            else {
                buttons[rowTemp][columnTemp].setImageResource(R.drawable.black);
                board[rowTemp][columnTemp] = "B";
                player = false;
            }
        }
        redButtonTouched = false;
        blackButtonTouched = false;
        board[row][column] = " ";
        lastRow = row;
        lastColumn = column;
        clearHelp();
        redIdMove = 0;
        blackIdMove = 0;
        printBoard();
        //multipleTakeSearch(id);
        mcallbacks.playerTurn(player);
        if (!player && taken){
            redPlayerCount--;
        }
        else if (player && taken){
            blackPlayerCount--;
        }
        System.out.println("reds: "+redPlayerCount+" blacks: "+blackPlayerCount);
        if (player && blackPlayerCount == 0){
           Dialog dialog = new Dialog(true);
           dialog.show(getFragmentManager(),"Test");
        }
        else if (!player && redPlayerCount == 0){
            Dialog dialog = new Dialog(false);
            dialog.show(getFragmentManager(),"Test");
        }

        System.out.println("END. takeable: "+takeable+" taken: "+taken);
       /* if (cpu && player){
            blackIds.remove((Integer) id);
            blackIds.add(newIdMove);
        }*/

    }

    public boolean allowedMove(int oldID, int newID) throws ArrayIndexOutOfBoundsException{
        boolean permit = false;
        int oldRow = Integer.parseInt(rowMap.get(oldID).toString());
        int oldColumn = Integer.parseInt(columnMap.get(oldID).toString());
        int newRow = Integer.parseInt(rowMap.get(newID).toString());
        int newColumn = Integer.parseInt(columnMap.get(newID).toString());
        //regular players cannot move backwards unless it is to jump an opponent
        if (board[oldRow][oldColumn].equals("BC") || board[oldRow][oldColumn].equals("RC") &&
                board[newRow][newColumn].equals("GC") ){
            permit = true;
            return permit;
        }
        if (board[oldRow][oldColumn].equals(" ") || board[oldRow][oldColumn].equals("-") ){
            System.out.println("NOT ALLOWED111");
            permit = false;
            return  permit;
        }
        if(board[oldRow][oldColumn].equals("R") && player ){
            permit = false;
            return permit;
        }
        if(newRow == oldRow || newColumn == oldColumn){
            permit = false;
            return permit;
        }
        if(board[oldRow][oldColumn].equals("B") && !player ){
            permit = false;
            return permit;
        }
        if (board[oldRow][oldColumn].equals("R")){
            if(!takeable && newRow - oldRow != -1 && newColumn - oldColumn != 1){
                permit = false;
                return permit;
            }
            if (newRow > oldRow && !takeable){
                permit = false;
                return permit;
            }
            if(board[newRow][newColumn].equals("R")){
                permit = false;
                return permit;
            }
            if(board[newRow][newColumn].equals("B")){
                permit = false;
                return permit;
            }
            if (oldRow + 1 <= 7 && oldColumn +1 <= 7 && board[oldRow + 1][oldColumn + 1].equals("B")){
                System.out.println("ALLOWED BACKWARDS RIGHT");
                permit = true;
                return permit;
            }
            if (oldRow + 1 <= 7 && oldColumn -1 >= 0 && board[oldRow + 1][oldColumn - 1].equals("B")){
                System.out.println("ALLowed back left");
                permit = true;
                return permit;
            }
        }
        else if (board[oldRow][oldColumn].equals("B")){
            if (newRow < oldRow && !takeable){
                permit = false;
                return permit;
            }
            if(board[newRow][newColumn].equals("R")){
                permit = false;
                return permit;
            }
            if(board[newRow][newColumn].equals("B")){
                permit = false;
                return permit;
            }
            if (oldRow - 1 >= 0 && oldColumn +1 <= 7 && board[oldRow - 1][oldColumn + 1].equals("R")){
                System.out.println("ALLOWED BACKWARDS RIGHT");
                permit = true;
                return permit;
            }
            if (oldRow - 1 >= 0 && oldColumn -1 >= 0 && board[oldRow - 1][oldColumn - 1].equals("R")){
                System.out.println("ALLowed back left");
                permit = true;
                return permit;
            }
        }
        if (board[newRow][newColumn].equals("G")){ permit = true; }

        return permit;
    }

    public void clearHelp(){
        boolean switcher = true;
        for (int i = 0; i < 8; i ++){
            if (switcher){ switcher = false; }
            else { switcher = true; }
            for (int j = 0; j < 8; j ++){
                if (board[i][j].equals("G")){
                    board[i][j] = " ";
                    buttons[i][j].setImageResource(R.color.black);
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                }
                if (board[i][j].equals("GC")){
                    board[i][j] = " ";
                    buttons[i][j].setImageResource(R.color.black);
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                }

            }
        }
    }

    //look back if the loop can be placed here to make the same player play again but the aim is to
    //set it
    // to 5 seconds then aftrwards do an interupt
     Handler threadHandler = new Handler(){
        @SuppressLint("HandlerLeak")
        public void handleMessage(android.os.Message message) {
            if (!player){

                makeMove(redIdMove,holder);
                if(taken && nextMoveRed(holder)){
                    if (board[row][column].equals("RC") && !crownTakeable){ clearHelp(); }
                    new CountDownTimer(5000,1000){
                        @Override
                        public void onTick(long millisUntilFinished) {
                            System.out.println(millisUntilFinished/1000);
                            player = false;

                        }

                        @Override
                        public void onFinish() {
                            player = true;
                            redButtonTouched = false;
                        }
                    }.start();
                }
                multiple = false;
                player = true;
            /*   if (cpu && player){
                    cpuMove();
                }*/

            }
            else{
                makeMove(blackIdMove,holder);
                if(taken && nextMoveBlack(holder)){
                    new CountDownTimer(5000,1000){
                        @Override
                        public void onTick(long millisUntilFinished) {
                            System.out.println(millisUntilFinished/1000);
                            player = true;
                        }

                        @Override
                        public void onFinish() {
                            player = false;
                        }
                    }.start();
                }
                multiple = false;
            }


        }
    };


    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            try {
                //while(true) {
                threadHandler.sendEmptyMessage(0);
                Thread.sleep(1000);
                //}
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };

    public boolean nextMoveRed(int id){
        boolean next = false;
        int rowTemp = Integer.parseInt(rowMap.get(id).toString());
        int columnTemp = Integer.parseInt(columnMap.get(id).toString());
        if (board[row][column].equals("RC")){ crownMover(rowTemp,columnTemp); }
        else if((rowTemp - 1) >= 0){
            if ((columnTemp - 1) >= 0){// check if the left move is available
                if (rowTemp - 2 >= 0 && columnTemp - 2 >= 0 && (board[rowTemp -1][columnTemp - 1].equals("B") ) && board[rowTemp -2][columnTemp - 2].equals(" ") ){
                    buttons[rowTemp -2][columnTemp -2].setBackgroundColor(Color.GREEN);
                    board[rowTemp - 2][columnTemp - 2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("ERROR");
                }
                if (rowTemp + 2 <= 7 && columnTemp - 2 >= 0 && (board[rowTemp +1][columnTemp - 1].equals("B") ) && board[row +2][columnTemp - 2].equals(" ")){
                    buttons[rowTemp +2][columnTemp -2].setBackgroundColor(Color.GREEN);
                    board[rowTemp + 2][columnTemp - 2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("ERROR");
                }

            }
            if ((columnTemp + 1) <= 7) {
                if (rowTemp - 2 >= 0 && columnTemp + 2 <= 7 && (board[rowTemp -1][columnTemp + 1].equals("B"))  && board[rowTemp -2][columnTemp +2].equals(" ")){
                    buttons[rowTemp -2][columnTemp +2].setBackgroundColor(Color.GREEN);
                    buttons[rowTemp -2][columnTemp +2].setImageResource(R.color.green);
                    board[rowTemp -2][columnTemp + 2] = "G";
                    next = true;
                    takeable = true;
                }
                if (rowTemp + 2 <= 7 && columnTemp + 2 <= 7 && (board[rowTemp +1][columnTemp + 1].equals("B") ) && board[rowTemp +2][columnTemp + 2].equals(" ") ){
                    buttons[rowTemp +2][columnTemp +2].setBackgroundColor(Color.GREEN);
                    board[rowTemp + 2][columnTemp +2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("BACKWARD TO RIGHT");
                }
            }

        }
        row = rowTemp;
        column = columnTemp;
        redButtonTouched = true;
        redIdMove = id;

       //System.out.println(takeable);
        return next;
    }

    public boolean nextMoveBlack(int id){
        boolean next = false;
        int rowTemp = Integer.parseInt(rowMap.get(id).toString());
        int columnTemp = Integer.parseInt(columnMap.get(id).toString());
        if (board[rowTemp][columnTemp].equals("BC")){ crownMover(rowTemp,columnTemp); }
        else if((rowTemp + 1) <= 7) {
            if ((columnTemp - 1) >= 0) {
                if (rowTemp + 2 <= 7 && columnTemp - 2 >= 0 && !board[rowTemp +1][columnTemp - 1].equals(" ")
                        && board[rowTemp +2][columnTemp - 2].equals(" ") &&
                        (board[rowTemp +1][columnTemp - 1].equals("R") )){
                    buttons[rowTemp +2][columnTemp -2].setBackgroundColor(Color.GREEN);
                    buttons[rowTemp +2][columnTemp -2].setImageResource(R.color.green);
                    board[rowTemp + 2][columnTemp - 2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("Black takable left");
                }
                if (rowTemp - 2 >= 0 && columnTemp - 2 >= 0 && (board[rowTemp -1][columnTemp - 1].equals("R") ) && board[rowTemp -2][columnTemp - 2].equals(" ")){
                    buttons[rowTemp -2][columnTemp -2].setBackgroundColor(Color.GREEN);
                    board[rowTemp - 2][columnTemp - 2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("ERROR");
                }

            }
            if ((columnTemp + 1) <= 7) {
                if (rowTemp + 2 <= 7 && columnTemp + 2 <= 7 && columnTemp - 1 >= 0 && columnTemp +1 <= 7
                        && board[rowTemp +2][columnTemp + 2].equals(" ")
                        && (board[rowTemp +1][columnTemp + 1].equals("RC") || board[rowTemp +1][columnTemp + 1].equals("R"))){
                    buttons[rowTemp +2][columnTemp +2].setBackgroundColor(Color.GREEN);
                    buttons[row +2][column +2].setImageResource(R.color.green);
                    board[rowTemp + 2][columnTemp +2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("Black takable right");
                }
                if (rowTemp - 2 >= 0 && columnTemp + 2 <= 7 && (board[rowTemp -1][columnTemp + 1].equals("R")
                        ) && board[rowTemp -2][columnTemp + 2].equals(" ")){
                    buttons[rowTemp -2][columnTemp +2].setBackgroundColor(Color.GREEN);
                    board[rowTemp -2][columnTemp +2] = "G";
                    takeable = true;
                    next = true;
                    System.out.println("ERROR");
                }

            }
        }
        row = rowTemp;
        column = columnTemp;
        blackButtonTouched= true;
        blackIdMove = id;
        //System.out.println(takeable);
        return next;
    }

//// redo this function to just check for places at a time that's it then extend the scope for the crowns
    private boolean multipleTakeSearch(int oldID){
        if(!takeable){ return false; }
        int oldRow = Integer.parseInt(rowMap.get(oldID).toString());
        int oldColumn = Integer.parseInt(rowMap.get(oldID).toString());
        //if(board[oldRow][oldColumn].equals(" ")){ return false;}
        System.out.println(row + " "+column);
        searcher(row,column," ",1);
        firstSearch = true;
       // System.out.println(multiple);
        return false;
    }
    /*
    if direction is true then the next search would
     */
    private void searcher(int oldRow, int oldColumn, String direction, int counter){
        if (firstSearch){ firstSearch = false; }
        else if (oldColumn > 7 || oldColumn < 0){ return; }
        else if (oldRow > 7 || oldRow < 0){ return; }
        else if (!board[oldRow][oldColumn].equals(" ")){ return; }
        else if(player && oldRow - 1 >= 0 && oldColumn - 1 >= 0 &&
                board[oldRow-1][oldColumn-1].equals("B")){ return; }
        else if(!player && oldRow - 1 >= 0 && oldColumn - 1 >= 0 &&
                board[oldRow-1][oldColumn-1].equals("R")){ return; }
        if (board[oldRow][oldColumn].equals(" ") || board[oldRow][oldColumn].equals("G")) {
            buttons[oldRow][oldColumn].setBackgroundColor(Color.WHITE);
            counter++;
            multiple = true;
            System.out.println(oldRow + " "+ oldColumn);

        }
        if (!direction.equals("NE")) {
            searcher(oldRow + 2, oldColumn - 2, "SW", counter++);
        }
        if (!direction.equals("NW")) {
            searcher(oldRow + 2, oldColumn + 2, "SE", counter++);
        }
        if (!direction.equals("SE")) {
            searcher(oldRow - 2, oldColumn - 2, "NW", counter++);
        }
        if (!direction.equals("SW")) {
            searcher(oldRow - 2, oldColumn + 2, "NE", counter++);
        }
    }

    public void crownMover(int oldRow, int oldColumn){
        boolean[] decider = new boolean[8];
        for (int j = 0; j < 8; j++){
            decider[j] = true;
        }
        for (int i = 1; i <= 7; i++){
            if(oldRow + i <=7 && oldColumn + i <=7 && decider[4] && board[oldRow + i][oldColumn + i].equals(" ")){
                buttons[oldRow + i][oldColumn + i].setBackgroundColor(Color.GREEN);
                board[oldRow + i][oldColumn + i] = "GC";
                System.out.println("THIS FOUND");
            }
            else if (!decider[0] && oldRow + i + 1 <= 7 && oldColumn + i +1 <= 7 &&
                    !board[oldRow + i ][oldColumn + i ].equals(" ")){
                decider[4] = false;
                crownTakeable = true;
            }
            else if (oldRow + i + 1 <= 7 && oldColumn + i +1 <= 7 &&
                    !board[oldRow + i][oldColumn + i].equals(" ")) {
                decider[0] = false;
            }


            if(oldRow + i <=7 && oldColumn - i >=0 && decider[5] && board[oldRow + i][oldColumn - i].equals(" ")){
                buttons[oldRow + i][oldColumn - i].setBackgroundColor(Color.GREEN);
                board[oldRow + i][oldColumn - i] = "GC";
            }
            else if (!decider[1] && oldRow + i + 1<= 7 && oldColumn - i -1 >= 0 &&
                    !board[oldRow + i][oldColumn - i].equals(" ")){
                decider[5] = false;
                crownTakeable = true;
            }
            else if (oldRow + i + 1 <= 7 && oldColumn - i - 1 >= 0 &&
                    !board[oldRow + i][oldColumn - i].equals(" ")) {
                decider[1] = false;
            }


            if(oldRow - i >=0 && oldColumn - i >=0 && decider[6] && board[oldRow - i][oldColumn - i].equals(" ")){
                buttons[oldRow - i][oldColumn - i].setBackgroundColor(Color.GREEN);
                board[oldRow - i][oldColumn - i] = "GC";
            }
            else if (!decider[2] && oldRow - i - 1 >= 0 && oldColumn - i -1 >= 0 &&
                    !board[oldRow - i][oldColumn - i].equals(" ")) {
                decider[6] = false;
                crownTakeable = true;
            }
            else if (oldRow - i - 1 >= 0 && oldColumn - i -1 >= 0 &&
                    !board[oldRow - i][oldColumn - i].equals(" ")) {
                decider[2] = false;
            }

            if(oldRow - i >=0 && oldColumn + i <=7 && decider[7] && board[oldRow - i][oldColumn + i].equals(" ")){
                buttons[oldRow - i][oldColumn + i].setBackgroundColor(Color.GREEN);
                board[oldRow - i][oldColumn + i] = "GC";
            }
            else if (!decider[3] && oldRow - i - 1 >= 0 && oldColumn + i + 1 <= 7 &&
                    !board[oldRow - i][oldColumn + i].equals(" ")) {
                decider[7] = false;
                crownTakeable = true;
            }
            else if (oldRow - i - 1 >= 0 && oldColumn + i + 1 <= 7 &&
                    !board[oldRow - i][oldColumn + i].equals(" ")) {
                decider[3] = false;
            }

        }
        //System.out.println(crownTakeable);

        printBoard();
    }

    public void crownTaker(int oldRow, int oldColumn, int newRow, int newColumn){
        int j = 0;
        if (oldRow < newRow) {
            if (oldColumn < newColumn){
                j = oldColumn;
                for (int i = oldRow + 1; i < newRow; i++){
                    //for (int j = oldColumn + 1; j < newColumn; j++){
                        buttons[i][++j].setImageResource(R.color.black);
                        if (!player && board[i][j].equals("B") || board[i][j].equals("BC")) {
                            redPlayerCount--;
                        }
                        else if (player && board[i][j].equals("R") || board[i][j].equals("RC")) {
                            redPlayerCount--;
                        }
                        buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                    //}
                }
            }
            if (oldColumn > newColumn){
                j = oldColumn;
                for (int i = oldRow + 1; i < newRow; i++){
                    //for (int j = oldColumn - 1; j > newColumn; j--){
                    buttons[i][--j].setImageResource(R.color.black);
                    buttons[i][j].setBackgroundColor(Color.BLACK);

                    if (!player && board[i][j].equals("B") || board[i][j].equals("BC")) {
                        redPlayerCount--;
                    }
                    else if (player && board[i][j].equals("R") || board[i][j].equals("RC")) {
                        redPlayerCount--;
                    }
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                    board[i][j] = " ";
                    System.out.println(j);
                    //}
                }
            }
        }
        if (oldRow > newRow) {
            j = oldColumn;
            if (oldColumn < newColumn){
                for (int i = oldRow - 1; i > newRow; i--){
                    //for (int j = oldColumn + 1; j < newColumn; j++){
                    buttons[i][++j].setImageResource(R.color.black);
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                    if (!player && board[i][j].equals("B") || board[i][j].equals("BC")) {
                        redPlayerCount--;
                    }
                    else if (player && board[i][j].equals("R") || board[i][j].equals("RC")) {
                        redPlayerCount--;
                    }
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";

                        System.out.println(j);
                    //}
                }
            }
            if (oldColumn > newColumn){
                j = oldColumn;
                for (int i = oldRow - 1; i > newRow; i--){
                    //for (int j = oldColumn - 1; j > newColumn; j--){
                    buttons[i][--j].setImageResource(R.color.black);
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                    if (!player && board[i][j].equals("B") || board[i][j].equals("BC")) {
                        redPlayerCount--;
                    }
                    else if (player && board[i][j].equals("R") || board[i][j].equals("RC")) {
                        redPlayerCount--;
                    }
                    buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                    //}
                }
            }
        }
        crownTakeable = false;
        taken = true;
    }



    public boolean penaltyRed(){
        boolean committed = false;
        takeableMoves = new boolean[8][8]; // replace with a 3x3 matrix of string and store the directions
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                takeableMoves[i][j] = false; //initialize each location
                if (board[i][j].equals("R")){
                    if (i + 2 <= 7 && j + 2 <= 7 && board[i+1][j+1].equals("B") && board[i+2][j+2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i + 2 <= 7 && j - 2 >= 0 && board[i+1][j-1].equals("B") && board[i+2][j-2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i - 2 >= 0 && j + 2 <= 7 && board[i-1][j+1].equals("B") && board[i-2][j+2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i - 2 >= 0 && j - 2 >= 0 && board[i-1][j-1].equals("B") && board[i-2][j-2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                }
                else if (board[i][j].equals("B")){
                    if (i + 2 <= 7 && j + 2 <= 7 && board[i+1][j+1].equals("R") && board[i+2][j+2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i + 2 <= 7 && j - 2 >= 0 && board[i+1][j-1].equals("R") && board[i+2][j-2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i - 2 >= 0 && j + 2 <= 7 && board[i-1][j+1].equals("R") && board[i-2][j+2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                    if (i - 2 >= 0 && j - 2 >= 0 && board[i-1][j-1].equals("R") && board[i-2][j-2].equals(" ")){
                        takeableMoves[i][j] = true;
                        committed = true;
                    }
                }
            }
        }
        return committed;
    }

    public void takeCheck() {
        if (penaltyRed() && !taken || crownTakeable) {
            System.out.println("PENALTY");
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (!player && board[i][j].equals("RC") && takeableMoves[i][j] && i != lastRow &&
                            crownTakeable && lastColumn != j) {
                        buttons[i][j].setImageResource(R.color.black);
                        buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                        crownTakeable = false;
                        redPlayerCount--;

                        takeable = false;
                        return;
                    } else if (player && board[i][j].equals("BC") && takeableMoves[i][j] && i != lastRow &&
                            crownTakeable && lastColumn != j) {
                        buttons[i][j].setImageResource(R.color.black);
                        buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                        crownTakeable = false;
                        redPlayerCount--;
                        taken = false;
                        takeable = false;
                        return;
                    } else if (!player && board[i][j].equals("R") && takeableMoves[i][j] && i != lastRow &&
                            lastColumn != j) {
                        buttons[i][j].setImageResource(R.color.black);
                        buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                        crownTakeable = false;
                        blackPlayerCount--;
                        taken = false;
                        takeable = false;
                        return;
                    } else if (player && board[i][j].equals("B") && takeableMoves[i][j] && i != lastRow &&
                            lastColumn != j) {
                        buttons[i][j].setImageResource(R.color.black);
                        buttons[i][j].setBackgroundColor(Color.BLACK);
                        board[i][j] = " ";
                        crownTakeable = false;
                        blackPlayerCount--;
                        taken = false;
                        takeable = false;
                        return;
                    }
                }
            }
        }
        taken = false;
    }

    public void printBoard(){
        for (int i = 0; i < 8; i ++){
            for (int j = 0; j < 8; j ++){
              System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }

}