package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NewGame extends AppCompatActivity implements Game.Callbacks {
    private FragmentManager fragmentManager;
    private TextView textView;
    private Game boardGame;
    private Bundle bundle;
    private  Button newGame, instruction;
    @SuppressLint("StaticFieldLeak")
    private static Button penalty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
        textView = findViewById(R.id.textView2);
        newGame = findViewById(R.id.newGameutton);
        instruction = findViewById(R.id.instructionButton);
        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewGame();
            }
        });
        instruction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInstructions();
            }
        });
        fragmentManager = getSupportFragmentManager();
        startNewGame();
    }

    @Override
    public void playerTurn(boolean player) {
        textView.setTextColor(Color.WHITE);
        if(!player){
            textView.setBackgroundColor(Color.RED);
            textView.setText("Player: Red");
        }
        else if(player){
            textView.setBackgroundColor(Color.BLACK);
            textView.setText("Player: Black");
        }
    }

    public void startNewGame(){
        bundle = new Bundle();
        bundle.putBoolean("cpuGame",true);
        boardGame = new Game();
        boardGame.setArguments(bundle);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment,boardGame).commit();
    }

    public void showInstructions(){
        InstructionFragment instructionFragment = new InstructionFragment();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment,instructionFragment).commit();
    }

    @Override
    public void penaltyCheck() {
        penalty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boardGame.takeCheck();
            }
        });
    }
}