package com.example.project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link InstructionFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class InstructionFragment extends Fragment {
    private String instruction;
    private TextView textView;

    public InstructionFragment() {
        instruction = "Jamaican Draught is similar to regular checkers but there are few rules that" +
                "makes it different and the rules are as follows:" +
                "1. In Jamaican Draught a regular player has the capability of movie backwards only if " +
                "jumping an opponent that is immediately behind that player." +
                "2. A crown has the capabilty of moving a full check vs only being able to move a single " +
                "check in checkers but just like in checkser a crown can move backwards at will." +
                "3. In Jamaocan Draughts taking an opponent's player when the opportunity arises is not " +
                "mandatory but failure to do so will result in a penalty and that player will be taken off" +
                "the board.";
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_instruction, container, false);
        textView = view.findViewById(R.id.instructionTextview);
        textView.setText(instruction);
        return view;
    }
}